package com.luckyframe.project.monitor.operlog.mapper;

import java.util.List;
import com.luckyframe.project.monitor.operlog.domain.OperLog;
import org.springframework.stereotype.Component;

/**
 * 操作日志 数据层
 * 
 * @author ruoyi
 */
@Component
public interface OperLogMapper
{
    /**
     * 新增操作日志
     * 
     * @param operLog 操作日志对象
     */
    void insertOperlog(OperLog operLog);

    /**
     * 查询系统操作日志集合
     * 
     * @param operLog 操作日志对象
     * @return 操作日志集合
     */
    List<OperLog> selectOperLogList(OperLog operLog);
    
    /**
     * 批量删除系统操作日志
     * 
     * @param ids 需要删除的数据
     * @return 结果
     */
    int deleteOperLogByIds(String[] ids);
    
    /**
     * 查询操作日志详细
     * 
     * @param operId 操作ID
     * @return 操作日志对象
     */
    OperLog selectOperLogById(Long operId);
    
    /**
     * 清空操作日志
     */
    void cleanOperLog();
}
