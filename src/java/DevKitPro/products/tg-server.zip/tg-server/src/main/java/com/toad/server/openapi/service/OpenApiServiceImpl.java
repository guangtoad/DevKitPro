package com.toad.server.openapi.service;

import com.toad.server.framework.BaseServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class OpenApiServiceImpl extends BaseServiceImpl implements IOpenApiService {

}
