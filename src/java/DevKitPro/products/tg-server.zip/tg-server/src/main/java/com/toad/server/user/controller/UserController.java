package com.toad.server.user.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.PostMapping;
/**
 * @author toad
 * @time 2023-12-21
 * @description TODO
 */
@Controller
@RequestMapping("/user")
public class UserController {
}
