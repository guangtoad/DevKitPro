package com.toad.server.openapi.controller;

import com.aliyun.cloudauth20190307.Client;
import com.aliyun.cloudauth20190307.models.*;
import com.aliyun.teaopenapi.models.Config;
import com.aliyun.teautil.models.RuntimeOptions;
import com.google.gson.Gson;
import com.toad.server.framework.BaseController;
import com.toad.server.openapi.service.IOpenApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

/**
 * @author toad
 * @time 2024-01-11
 * @description TODO
 */

@RestController
@RequestMapping("/openapi/aliyun")
public class OpenApiAliyunController extends BaseController {
    static private final Long Sceneid = 1000008965L;
    static private final String OuterOrderNo = "e0c34a77f5ac40a5aa5e6ed20c353888";

    //    static private final String AccessKeyId = "LTAI5tLwFiCYXx3hhG1dFkHS";
    static private final String AccessKeyId = "LTAI5tLwFiCYXx3hhG1dFkHS";
    static private final String AccessKeySecret = "vCistYQuZW5uxEnwVa7vh6O5aNP9By";

    @Autowired
    private IOpenApiService openApiService;
    @RequestMapping("/test")
    public String aliAPI(){
        return "OK";
    }
    @RequestMapping("/InitFaceVerify")
    public String InitFaceVerify(){

        return "{\"code\":\"200\",\"message\":\"success\",\"requestId\":\"E197F9DE-0B73-5E52-972C-32E5814EA88C\",\"resultObject\":{\"certifyId\":\"shab0f4b553236af3f55d8360d91820c\"}}";

//        String result = "ok";
//        try {
//
//            InitFaceVerifyRequest request = new InitFaceVerifyRequest();
//            // 请输入场景ID+L。
//            request.setSceneId(Sceneid);
//            // 设置商户请求的唯一标识。
//            request.setOuterOrderNo(OuterOrderNo);
//            // 认证方案。
//            // request.setProductCode("ID_PRO");
//            request.setProductCode("ID_PLUS");
//
//            // 模式。
////            request.setModel("LIVENESS");
////            request.setCertType("IDENTITY_CARD");
////            request.setCertName("张先生");
////            request.setCertNo("210104198706102313");
//            // MetaInfo环境参数。
//            request.setMetaInfo("{}");
//            //request.setMobile("130xxxxxxxx");
//            //request.setIp("114.xxx.xxx.xxx");
//            //request.setUserId("12345xxxx");
//            //request.setCallbackUrl("https://www.aliyundoc.com");
//            //request.setCallbackToken("xxxxx");
//            // 如需开启个人信息加密传输。
//            //request.setEncryptType("SM2");
//            //request.setCertName("BCRD/7ZkNy7Q*****M1BMBezZe8GaYHrLwyJv558w==");
//            //request.setCertNo("BMjsstxK3S4b1YH*****Pet8ECObfxmLN92SLsNg==");
//
//            // 推荐，支持服务路由。
//            InitFaceVerifyResponse response = initFaceVerifyAutoRoute(request);
//
//            // 不支持服务自动路由。
//            //InitFaceVerifyResponse response = initFaceVerify("cloudauth.cn-shanghai.aliyuncs.com", request);
//
//            response.getBody().getRequestId();
//            response.getBody().getResultObject().getCertifyId();
//
//            System.out.println(response.getBody().getRequestId());
//            System.out.println(response.getBody().getCode());
//            System.out.println(response.getBody().getMessage());
//
//            System.out.println(response.getBody().getResultObject() == null ? null
//                    : response.getBody().getResultObject().getCertifyId());
//            response.getStatusCode();
//            InitFaceVerifyResponseBody body = response.getBody();
//            result = new Gson().toJson(body);
//        }
//        catch (Exception e) {
//            e.printStackTrace();
//            result = "{\"code\":\"9999\",\"msg\":\"error\"}";
//        }
//        return result;
    }

    private static InitFaceVerifyResponse initFaceVerifyAutoRoute(InitFaceVerifyRequest request) {
        // 第一个为主区域Endpoint，第二个为备区域Endpoint。
        List<String> endpoints = Arrays.asList("cloudauth.cn-shanghai.aliyuncs.com", "cloudauth.cn-beijing.aliyuncs.com");
        InitFaceVerifyResponse lastResponse = null;
        for (int i=0; i<endpoints.size(); i++) {
            try {
                InitFaceVerifyResponse response = initFaceVerify(endpoints.get(i), request);
                lastResponse = response;

                // 服务端错误，切换到下个区域调用。
                if(response != null){
                    if(500 == response.getStatusCode()){
                        continue;
                    }
                    if(response.getBody() != null){
                        if("500".equals(response.getBody().getCode())){
                            continue;
                        }
                    }
                }

                // 正常返回
                return lastResponse;
            }catch (Exception e) {
                e.printStackTrace();
                if(i == endpoints.size()-1){
                    throw new RuntimeException(e);
                }
            }
        }

        return lastResponse;
    }

    private static InitFaceVerifyResponse initFaceVerify(String endpoint, InitFaceVerifyRequest request)
            throws Exception {
        // 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
        // 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
        // 本示例通过阿里云Credentials工具从环境变量中读取AccessKey，来实现API访问的身份验证。如何配置环境变量，请参见https://help.aliyun.com/document_detail/378657.html。
//        com.aliyun.credentials.Client credentialClient = new com.aliyun.credentials.Client();

        Config config = new Config();
//        config.setCredential(credentialClient);
        config.setAccessKeyId(AccessKeyId);
        config.setAccessKeySecret(AccessKeySecret);
        config.setEndpoint(endpoint);
//        config.setA
        // 设置http代理。
        //config.setHttpProxy("http://xx.xx.xx.xx:xxxx");
        // 设置https代理。
        //config.setHttpsProxy("https://xx.xx.xx.xx:xxxx");
        Client client = new Client(config);

        // 创建RuntimeObject实例并设置运行参数。
        RuntimeOptions runtime = new RuntimeOptions();
        runtime.readTimeout = 10000;
        runtime.connectTimeout = 10000;

        return client.initFaceVerifyWithOptions(request, runtime);
    }

    @RequestMapping("/DescribeFaceVerify/{CertifyId}")
    public String DescribeFaceVerify(@PathVariable(name= "CertifyId") String CertifyId){

        // 通过以下代码创建API请求并设置参数。
        DescribeFaceVerifyRequest request = new DescribeFaceVerifyRequest();
        // 请输入场景ID+L。
        request.setSceneId(0L);
        request.setCertifyId(CertifyId);
        // 请输入场景ID+L。
        request.setSceneId(Sceneid);
        // 推荐，支持服务路由。
        DescribeFaceVerifyResponse response = describeFaceVerifyAutoRoute(request);
        // 不支持服务自动路由。
        //DescribeFaceVerifyResponse response = describeFaceVerify("cloudauth.cn-shanghai.aliyuncs.com", request);
        System.out.println(response.getBody().getRequestId());
        System.out.println(response.getBody().getCode());
        System.out.println(response.getBody().getMessage());
        System.out.println(
                response.getBody().getResultObject() == null ? null : response.getBody().getResultObject().getPassed());
        System.out.println(
                response.getBody().getResultObject() == null ? null : response.getBody().getResultObject().getSubCode());
        System.out.println(
                response.getBody().getResultObject() == null ? null
                        : response.getBody().getResultObject().getIdentityInfo());
        System.out.println(
                response.getBody().getResultObject() == null ? null
                        : response.getBody().getResultObject().getDeviceToken());
        System.out.println(
                response.getBody().getResultObject() == null ? null
                        : response.getBody().getResultObject().getMaterialInfo());
        return "ok";
    }

    private static DescribeFaceVerifyResponse describeFaceVerifyAutoRoute(DescribeFaceVerifyRequest request) {
        // 第一个为主区域Endpoint，第二个为备区域Endpoint。
        List<String> endpoints = Arrays.asList("cloudauth.cn-shanghai.aliyuncs.com", "cloudauth.cn-beijing.aliyuncs.com");
        DescribeFaceVerifyResponse lastResponse = null;
        for (int i = 0; i < endpoints.size(); i++) {
            try {
                DescribeFaceVerifyResponse response = describeFaceVerify(endpoints.get(i), request);
                lastResponse = response;

                // 服务端错误，切换到下个区域调用。
                if (response != null) {
                    if (500 == response.getStatusCode()) {
                        continue;
                    }
                    if (response.getBody() != null) {
                        if ("500".equals(response.getBody().getCode())) {
                            continue;
                        }
                    }
                }

                return lastResponse;
            } catch (Exception e) {
                if (i == endpoints.size() - 1) {
                    throw new RuntimeException(e);
                }
            }
        }

        return lastResponse;
    }

    private static DescribeFaceVerifyResponse describeFaceVerify(String endpoint, DescribeFaceVerifyRequest request)
            throws Exception {
        // 阿里云账号AccessKey拥有所有API的访问权限，建议您使用RAM用户进行API访问或日常运维。
        // 强烈建议不要把AccessKey ID和AccessKey Secret保存到工程代码里，否则可能导致AccessKey泄露，威胁您账号下所有资源的安全。
        //本示例通过阿里云Credentials工具从环境变量中读取AccessKey，来实现API访问的身份验证。如何配置环境变量，请参见https://help.aliyun.com/document_detail/378657.html。
//        com.aliyun.credentials.Client credentialClient = new com.aliyun.credentials.Client();
        Config config = new Config();

        config.setAccessKeyId(AccessKeyId);
        config.setAccessKeySecret(AccessKeySecret);
//        config.setCredential(credentialClient);
        config.setEndpoint(endpoint);
        // 设置http代理。
        //config.setHttpProxy("http://xx.xx.xx.xx:xxxx");
        // 设置https代理。
        //config.setHttpsProxy("http://xx.xx.xx.xx:xxxx");
        Client client = new Client(config);

        // 创建RuntimeObject实例并设置运行参数。
        RuntimeOptions runtime = new RuntimeOptions();
        runtime.readTimeout = 10000;
        runtime.connectTimeout = 10000;

        return client.describeFaceVerifyWithOptions(request, runtime);
    }


}
