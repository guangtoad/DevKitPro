package com.toad.server.service;

import com.toad.server.framework.BaseServiceImpl;
import com.toad.server.web.mockapi.domain.MockApi;
import com.toad.server.web.mockapi.mapper.MockApiMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MockApiManagerServiceImpl extends BaseServiceImpl implements IMockApiManagerService {

    @Autowired
    protected MockApiMapper mockApiMapper;

    @Override
    public List<MockApi> selectMockApiList(MockApi mockApi) {
        return mockApiMapper.selectMockApiList(mockApi);
    }

    @Override
    public List<MockApi> selectMockApiListAll() {
        return mockApiMapper.selectMockApiListAll();
    }

}
