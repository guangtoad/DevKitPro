package com.toad.server.service;

import com.toad.server.framework.common.uils.TreeUtils;
import com.toad.server.domain.Menu;
import com.toad.server.framework.BaseServiceImpl;
import com.toad.server.mapper.MenuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuServiceImpl extends BaseServiceImpl implements IMenuService  {

    @Autowired
    private MenuMapper menuMapper;

    @Override
    public List<Menu> selectMenuAll() {
        List<Menu> menus = menuMapper.selectMenuAll();
        return TreeUtils.getChildPerms(menus, 0);
    }
}
