package com.toad.server.web.mockapi.mapper;

import com.toad.server.web.mockapi.domain.MockApi;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface MockApiMapper {
    public List<MockApi> selectMockApiList(MockApi mockApi);
    public List<MockApi> selectMockApiListAll();
}
