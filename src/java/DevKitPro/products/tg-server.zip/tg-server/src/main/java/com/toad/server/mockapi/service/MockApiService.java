package com.toad.server.mockapi.service;

import com.toad.server.framework.IBaseService;

/**
 * @author toad
 * @time 2024-01-26
 * @description TODO
 */
public class MockApiService implements IBaseService {
}
