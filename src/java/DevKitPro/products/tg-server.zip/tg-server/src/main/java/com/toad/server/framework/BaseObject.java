package com.toad.server.framework;

import com.toad.server.config.ServerConfig;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
//@ConfigurationProperties(prefix = "toolsServer")
public class BaseObject {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    protected ServerConfig config;

}
