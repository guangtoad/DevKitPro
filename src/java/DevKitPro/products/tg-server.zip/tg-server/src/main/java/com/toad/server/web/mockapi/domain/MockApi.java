package com.toad.server.web.mockapi.domain;

import com.toad.server.framework.BaseEntity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
public class MockApi extends BaseEntity {

    private Long apiId;
    private String apiName;
    private String url;
    private boolean schemasVerificationEnabled;
    private String visible;

}
