package com.toad.server.service;


import com.toad.server.framework.IBaseService;
import com.toad.server.web.mockapi.domain.MockApi;

import java.util.List;

public interface IMockApiManagerService extends IBaseService {
    List<MockApi> selectMockApiList(MockApi mockApi);
    List<MockApi> selectMockApiListAll();
}
