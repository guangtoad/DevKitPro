package com.toad.server.web.client.mapper;


public interface ClientMapper {
}
