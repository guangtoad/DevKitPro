package com.toad.server.service;

import org.springframework.stereotype.Service;

@Service("permission")
public class PermissionService {
    public String hasPermi(String permission)
    {
        return isPermittedOperator(permission) ? "" : "hidden";
    }

    private boolean isPermittedOperator(String permission)
    {
        return true;
//        return SecurityUtils.getSubject().isPermitted(permission);
    }
}
