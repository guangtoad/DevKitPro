package com.toad.server.web.onlinetools.controller;


import com.toad.server.framework.BaseWebController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/onlinetools")
public class OnlineToolsController extends BaseWebController {

    @RequestMapping(value="/{page}",method= RequestMethod.GET)
    String other(@PathVariable(name = "page",required = false) String page) {
        return this.templatesPath(page);
    }
}
