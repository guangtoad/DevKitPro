package com.toad.server.web.onlinetools.controller;

import com.toad.server.framework.BaseWebController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/onlinetoolsmanager")
public class OnlineToolsManagerController extends BaseWebController {

    public OnlineToolsManagerController(){
        this.templatesPrefix = "/onlinetoolsmanager";
    }
    @GetMapping("/index")
    public String index(ModelMap mmap){
        return this.templatesPath("index");
    }
    /**
     * 新增协议模板管理
     */
    @GetMapping({"/add","/add/{parentId}"})
    public String add(ModelMap mmap)
    {
//        List<Project> projects=projectService.selectProjectAll(0);
//        mmap.put("projects", projects);
//        if(StringUtils.isNotEmpty(ShiroUtils.getProjectId())){
//            mmap.put("defaultProjectId", ShiroUtils.getProjectId());
//        }

        return this.templatesPath("add");
    }

//    @PostMapping("/add")
//    @ResponseBody
//    public AjaxResult addSave()
//    {
////        return toAjax(${classname}Service.insert${className}(${classname}));
//    }

}
