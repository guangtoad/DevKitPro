package com.toad.server.framework;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

public class BaseController extends BaseObject{

    @InitBinder
    public void initBinder(WebDataBinder binder)
    {
        this.logger.info("initBinder");
    }

}
