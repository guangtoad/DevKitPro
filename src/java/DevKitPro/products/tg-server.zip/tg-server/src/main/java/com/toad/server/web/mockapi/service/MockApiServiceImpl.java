package com.toad.server.web.mockapi.service;


import com.toad.server.framework.BaseServiceImpl;

public class MockApiServiceImpl extends BaseServiceImpl implements IMockApiService {


}
