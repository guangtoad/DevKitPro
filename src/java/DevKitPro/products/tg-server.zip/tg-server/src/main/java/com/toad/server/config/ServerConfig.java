package com.toad.server.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "toolsserver")
public class ServerConfig {

    private String name;
    private String version;
    private boolean demoEnabled;
    private boolean addressEnabled;

    @Value("${web.siteName:index}")
    private String siteName;

    @Value("${web.indexPageName:index}")
    private String indexPageName;
    @Value("${web.addPageName:add}")
    private String addPageName;
    @Value("${web.editPageName:edit}")
    private String editPageName;

}
