package com.toad.server.framework;

public interface IBaseService {
}
