package com.toad.server.openapi.service;


import com.toad.server.framework.IBaseService;

public interface IOpenApiService extends IBaseService {

}
