package com.toad.server.web.client.controller;

import com.toad.server.framework.BaseWebController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/client")
public class ClientController extends BaseWebController {

}
