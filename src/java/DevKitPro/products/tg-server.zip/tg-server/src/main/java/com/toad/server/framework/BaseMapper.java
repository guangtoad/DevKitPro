package com.toad.server.framework;

public class BaseMapper {
}
