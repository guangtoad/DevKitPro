package com.toad.server.web.mockapi.controller;

import com.toad.server.framework.BaseWebController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.HandlerMapping;

@RestController
@RequestMapping("/mock")
public class MockApiController extends BaseWebController {

    @RequestMapping("/api/**")
    @ResponseBody
    public ResponseEntity<String> reqeuestApi(){
        return ResponseEntity.status(200)
//                .headers(httpHeaders)
                .body("a");
    }

    @ResponseBody
    @RequestMapping(value="/webjarslocator/{webjar}/**")
    public ResponseEntity<String> locateWebjarAsset(@PathVariable String webjar,
                                                      WebRequest request) {
        try {
            String mvcPrefix ="/webjarslocator/" + webjar +"/";
            String mvcPath = (String) request.getAttribute(
                    HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST);
            this.logger.info("mvcPath:" + mvcPath);
        } catch (Exception e) {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.status(200).body("123");
    }

}
