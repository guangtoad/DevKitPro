package com.toad.server.controller;

import com.toad.server.domain.Menu;
import com.toad.server.framework.BaseWebController;
import com.toad.server.user.domain.User;
import com.toad.server.service.IMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class IndexController extends BaseWebController {

    @Autowired
    private IMenuService menuService;

    @GetMapping(value = {"/index","/"})
    public String index(ModelMap modelMap){

        User user = new User();
        user.setLoginName("toad");
        modelMap.put("user", user);

        List<Menu> menus = menuService.selectMenuAll();
        modelMap.put("menus", menus);
        modelMap.put("version", this.config.getVersion());
        return "index";
    }
    @GetMapping("/system/main")
    public String main(ModelMap mmap)
    {
        mmap.put("version", this.config.getVersion());
        return "main";
    }
}
