package com.toad.server.service;

import com.toad.server.framework.BaseServiceImpl;
import org.springframework.stereotype.Service;

@Service("config")
public class WebConfigServiceImpl extends BaseServiceImpl implements IWebConfigService {
    public String getKey(String configKey)
    {
        return "";
    }

    public String getSiteName(){
        return this.config.getSiteName();
    }
}
