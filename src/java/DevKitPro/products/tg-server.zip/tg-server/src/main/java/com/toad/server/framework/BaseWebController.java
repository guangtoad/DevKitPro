package com.toad.server.framework;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.toad.server.framework.common.uils.StringUtils;
import com.toad.server.domain.AjaxResult;
import com.toad.server.framework.page.PageDomain;
import com.toad.server.framework.page.TableDataInfo;
import com.toad.server.framework.page.TableSupport;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@Getter
@Setter
@ToString
public class BaseWebController extends BaseController{

//    protected String in
    public String templatesPrefix;

    public BaseWebController(){
        try {

            RequestMapping requestMapping = this.getClass().getDeclaredAnnotation(RequestMapping.class);
            if (null != requestMapping && requestMapping.value().length > 0) {
                this.templatesPrefix = requestMapping.value()[0];
            }
        }
        catch (Exception e){
            this.logger.error(e.toString());
        }

    }
    public String templatesPath(String path){
        String result = "";
        if (null == templatesPrefix || templatesPrefix.length() < 1){
            result = path;
        }
        else {
            if (null != path && path.length() > 0)
                return templatesPrefix + "/" + path;
            return "";
        }
        this.logger.info("result：" + result);
        return result;
    }
    public String indexTemplatePath(){
        return templatesPath(this.config.getIndexPageName());
    }
    public String addTemplatePath(){
        return templatesPath(this.config.getAddPageName());
    }
    public String editTemplatePath(){
        return templatesPath(this.config.getEditPageName());
    }

    /**
     * 响应返回结果
     *
     * @param rows 影响行数
     * @return 操作结果
     */
    protected AjaxResult toAjax(int rows)
    {
        return rows > 0 ? success() : error();
    }

    /**
     * 响应返回结果
     *
     * @param result 结果
     * @return 操作结果
     */
    protected AjaxResult toAjax(boolean result)
    {
        return result ? success() : error();
    }

    /**
     * 返回成功
     */
    public AjaxResult success()
    {
        return AjaxResult.success();
    }

    /**
     * 返回失败消息
     */
    public AjaxResult error()
    {
        return AjaxResult.error();
    }

    /**
     * 返回成功消息
     */
    public AjaxResult success(String message)
    {
        return AjaxResult.success(message);
    }

    /**
     * 返回失败消息
     */
    public AjaxResult error(String message)
    {
        return AjaxResult.error(message);
    }

    /**
     * 返回错误码消息
     */
    public AjaxResult error(int code, String message)
    {
        return AjaxResult.error(code, message);
    }
    /**
     * 设置请求分页数据
     */
    protected void startPage()
    {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();
        if (StringUtils.isNotNull(pageNum) && StringUtils.isNotNull(pageSize))
        {
            String orderBy = pageDomain.getOrderBy();
            PageHelper.startPage(pageNum, pageSize, orderBy);
        }
    }
    /**
     * 响应请求分页数据
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    protected TableDataInfo getDataTable(List<?> list)
    {
        TableDataInfo rspData = new TableDataInfo();
        rspData.setCode(0);
        rspData.setRows(list);
        rspData.setTotal(new PageInfo(list).getTotal());
        return rspData;
    }

}
