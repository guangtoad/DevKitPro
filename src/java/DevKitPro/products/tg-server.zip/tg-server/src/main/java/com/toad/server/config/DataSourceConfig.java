package com.toad.server.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSourceConfig {
    @Override
    public String toString() {
        return super.toString();
    }
}
