package com.toad.server.mapper;

import com.toad.server.domain.Menu;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface MenuMapper {
    List<Menu> selectMenuAll();
}
