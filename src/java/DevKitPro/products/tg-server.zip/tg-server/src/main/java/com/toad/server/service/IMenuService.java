package com.toad.server.service;

import com.toad.server.domain.Menu;
import com.toad.server.framework.IBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IMenuService extends IBaseService {

    /**
     * 查询所有菜单集合
     * @return 所有菜单
     */
    List<Menu> selectMenuAll();
}
