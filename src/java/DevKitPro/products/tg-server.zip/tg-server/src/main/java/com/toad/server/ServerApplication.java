package com.toad.server;

import com.github.pagehelper.dialect.auto.DataSourceAutoDialect;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import javax.sql.DataSource;

/**
 * @author toad
 * @time 2023-12-22
 * @description TODO
 */
@SpringBootApplication(exclude = {})
@MapperScan({"com.toad.server.mapper", "com.toad.server.*.mapper", "com.toad.server.*.*.mapper"})
public class ServerApplication extends SpringBootServletInitializer {
    public static void main(String[] args) {

        try {
            System.setProperty("spring.devtools.restart.enabled", "false");
            SpringApplication.run(ServerApplication.class, args);
        }
        catch (Exception e){
            e.printStackTrace();
        }
//        log.info("LuckyFrameWeb启动成功......");
    }
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(ServerApplication.class);
    }
}