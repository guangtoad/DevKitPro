package com.toad.server.web.mockapi.service;

import com.toad.server.framework.IBaseService;

public interface IMockApiService extends IBaseService {

}
