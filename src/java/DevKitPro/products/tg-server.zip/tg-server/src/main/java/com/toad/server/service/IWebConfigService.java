package com.toad.server.service;


import com.toad.server.framework.IBaseService;

public interface IWebConfigService extends IBaseService {

}
