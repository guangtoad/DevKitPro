package com.toad.server.web.monitor.controller;

import com.toad.server.framework.BaseWebController;
import com.toad.server.web.monitor.domain.ServerInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/monitor")
public class MonitorController extends BaseWebController {
    public MonitorController(){
        this.templatesPrefix = "/monitor";
    }

    @GetMapping("/server")
    public String server(ModelMap modelMap) throws Exception {
        ServerInfo serverInfo = new ServerInfo();
        serverInfo.copyTo();
        modelMap.put("server", serverInfo);
        return this.templatesPath("server");
    }
    @GetMapping("/logs")
    public String logs(ModelMap modelMap) {
        return this.templatesPath("logs");
    }
    @GetMapping("/apipage")
    public String apipage(ModelMap modelMap) {
        return this.templatesPath("apipage");
    }
}
