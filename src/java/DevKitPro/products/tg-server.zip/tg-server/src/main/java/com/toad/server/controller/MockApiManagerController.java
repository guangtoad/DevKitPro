package com.toad.server.controller;

import com.toad.server.framework.BaseWebController;
import com.toad.server.web.mockapi.domain.MockApi;
import com.toad.server.framework.page.TableDataInfo;
import com.toad.server.service.IMockApiManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@Controller
@RequestMapping("/mockapimanager")
public class MockApiManagerController extends BaseWebController {

    @Autowired
    private IMockApiManagerService mockApiManagerService;
    @GetMapping({"/index","/"})
    public String index(ModelMap modelMap){
        return this.indexTemplatePath();
    }

    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(MockApi mockApi)
    {
        startPage();
        List<MockApi> list = this.mockApiManagerService.selectMockApiList(mockApi);
        TableDataInfo tableDataInfo = getDataTable(list);
        return tableDataInfo;
    }
    /**
     * 新增调度
     */
    @GetMapping("/add")
    public String add()
    {
        return this.templatesPath("add");
    }
    @PostMapping("/add")
    public boolean add(ModelMap modelMap){
        return false;
    }

}
