package com.toad.server.mockapi.controller;

import com.toad.server.framework.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author toad
 * @time 2024-01-26
 * @description TODO
 */
@RequestMapping("/mockapimanager")
public class MockApiManagerController extends BaseController {

}
