package com.toad.server.framework;

public class BaseServiceImpl extends BaseObject {

}
