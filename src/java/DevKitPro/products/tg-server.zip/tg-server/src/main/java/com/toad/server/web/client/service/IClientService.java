package com.toad.server.web.client.service;

import com.toad.server.framework.IBaseService;
import org.springframework.stereotype.Service;

@Service
public interface IClientService extends IBaseService {

}
