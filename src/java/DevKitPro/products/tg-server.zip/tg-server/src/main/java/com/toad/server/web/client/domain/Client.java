package com.toad.server.web.client.domain;

import com.toad.server.framework.BaseEntity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
public class Client extends BaseEntity {

}
