package com.toad.server.web.client.service;


import com.toad.server.framework.BaseServiceImpl;

public class ClinetServiceImpl extends BaseServiceImpl {
}
