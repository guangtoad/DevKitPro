package com.toad.server.mockapi.controller.sse;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

public class SseTest {

    SseEmitter emitter = new SseEmitter();
//    public sdfsdf(){
////        const eventSource = new EventSource('http_api_url',{withCredentials: true})
////        eventSource
//    }
}
