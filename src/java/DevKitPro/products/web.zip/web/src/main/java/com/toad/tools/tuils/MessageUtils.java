package com.toad.tools.tuils;

public class MessageUtils {
    public static String failMessage(String type, int code){
        return "";
    }
}
