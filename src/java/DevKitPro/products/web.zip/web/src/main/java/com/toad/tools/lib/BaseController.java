package com.toad.tools.lib;

import com.toad.tools.common.utils.StringUtils;
import com.toad.tools.tuils.ShiroUtils;
import com.toad.tools.lib.BaseWebMVC;
import com.toad.tools.web.config.ToolsWebConfig;
import com.toad.tools.web.domain.AjaxResult;
import com.toad.tools.web.user.domain.User;
import lombok.Getter;
import lombok.Setter;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

@Controller
@Getter
@Setter
public class BaseController extends BaseWebMVC {

//    private static Logger log= LoggerFactory.getLogger(this.getClass());
    protected String basePath = "";

    @InitBinder
    public void InitBinderBasePath(WebDataBinder webDataBinder){
        this.logger.info("BaseController InitBinderBasePath");
    }
    public String templateByBasePath(String subPath){
        if (null != this.basePath){
            return this.basePath + subPath;
        }
        return subPath;
    }

    @Autowired
    protected ToolsWebConfig toolsWebConfig;
    /**
     * 返回成功
     */
    public AjaxResult success()
    {
        return AjaxResult.success();
    }
    /**
     * 返回失败消息
     */
    public AjaxResult error(String message)
    {
        return AjaxResult.error(message);
    }
    public User getSysUser()
    {
        return ShiroUtils.getSysUser();
    }


    /**
     * 页面跳转
     */
    public String redirect(String url)
    {
        return StringUtils.format("redirect:{}", url);
    }
}
