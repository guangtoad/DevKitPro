package com.toad.tools.web.mockapi.service;

import com.toad.tools.web.mockapi.doamin.MockApi;
import com.toad.tools.web.mockapi.exception.MockApiException;
import com.toad.tools.web.mockapi.mapper.MockApiMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Service
public class MockApiServiceImpl implements IMockApiService {

	@Autowired
	private  MockApiMapper mockApiMapper;
	@Override
	public List<MockApi> selectMockApiALL() {
		return mockApiMapper.selectMockApiALL();
	}

	@Override
	public List<MockApi> selectMockApiByUrl(String url) {
		return mockApiMapper.selectMockApiByUrl(url);
	}

	@Override
	public int updateMockAPI(MockApi mockApi) {
		return mockApiMapper.updateMockAPI(mockApi);
	}

	@Override
	public int insertMockApi(MockApi mockApi) {
		return mockApiMapper.insertMockApi(mockApi);
	}

	@Override
	public int deleteMockApi(MockApi mockApi) {
		return mockApiMapper.deleteMockApi(mockApi);
	}

	@Override
	public ResponseEntity<String> requestApi(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	@Override
	public ResponseEntity<String> requestApi(String url, String body, Map<String, String> headers, Map<String, String> params) throws MockApiException {
		mockApiMapper.selectMockApiByUrl(url);
		return null;
	}

}
