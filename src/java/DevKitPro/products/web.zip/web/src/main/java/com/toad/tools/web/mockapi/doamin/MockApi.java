package com.toad.tools.web.mockapi.doamin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MockApi {
	private int apiId;
	private String apiName;
	private String url;

}
