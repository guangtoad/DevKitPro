package com.toad.tools.web.exception;

public class WebExcetopn extends Exception{

}
