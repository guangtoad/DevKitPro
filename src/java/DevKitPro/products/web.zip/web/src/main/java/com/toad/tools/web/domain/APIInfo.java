package com.toad.tools.web.domain;

public class APIInfo {
}
