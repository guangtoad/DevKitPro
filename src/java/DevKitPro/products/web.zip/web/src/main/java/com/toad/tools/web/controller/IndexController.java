package com.toad.tools.web.controller;

import com.toad.tools.lib.BaseController;
import com.toad.tools.web.system.doamin.Menu;
import com.toad.tools.web.api.service.ApiServiceImpl;
import com.toad.tools.web.system.service.IMenuService;
import com.toad.tools.web.user.domain.User;
import com.toad.tools.web.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class IndexController extends BaseController {
    @Autowired
    private IMenuService menuService;
    @Autowired
    private ApiServiceImpl apiServiceImpl;
    // 系统首页
    @GetMapping(value = {"/index","/"})
    public String index(ModelMap modelMap)
    {

//        // 取身份信息
//        User user = getSysUser();
        User user = new User();
        user.setLoginName("toad");
//        // 根据用户id取出菜单
        List<Menu> menus = menuService.selectMenuAll();
//        List<Menu> menus = menuService.selectMenusByUser(user);
        modelMap.put("menus", menus);
        menus.size();
        this.toolsWebConfig.getName();
        modelMap.put("version", this.toolsWebConfig.getVersion());

        modelMap.put("user", user);
//        modelMap.put("copyrightYear", webConfig.getCopyrightYear());
//        modelMap.put("version", lfConfig.getVersion());
        return "index";
    }
    // 系统介绍
    @GetMapping("/system/main")
    public String main(ModelMap mmap)
    {
        mmap.put("version", this.toolsWebConfig.getVersion());
        return "main";
    }
    @RequestMapping("/userin")
    public ModelAndView index(){
        ArrayList<UserVo> userVos = new ArrayList<>();
        UserVo userVo = new UserVo();
        userVo.setId(1);
        userVo.setUsername("huznzi");
        userVos.add(userVo);
        UserVo userVo2 = new UserVo();
        userVo2.setId(2);
        userVo2.setUsername("huznzi2");
        userVos.add(userVo2);

        ModelAndView mv=new ModelAndView();
        mv.addObject("newText","你好，springboot-thymeleaf");
        mv.addObject("gender","1");
        mv.addObject("userList",userVos);
        mv.addObject("loginUser",userVo);
        mv.setViewName("index2.html");
        return mv;
    }
}
