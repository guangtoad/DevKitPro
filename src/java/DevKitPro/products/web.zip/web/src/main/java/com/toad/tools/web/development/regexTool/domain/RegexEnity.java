package com.toad.tools.web.development.regexTool.domain;

import com.toad.tools.annotation.Excel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegexEnity {

	/** 序列号 */
	@Excel(name = "序号")
	private Long regexID;

	private Long regexName;
}
