package com.toad.tools.web.user.mapper;

import com.toad.tools.web.user.domain.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper {
    List<User> findAll();
    List<User> findAllTwo();
    User selectUserByLoginName(String userName);
    int updateUserInfo(User user);
    /**
     * 修改用户信息
     *
     * @param user 用户信息
     * @return 结果
     */
//    int updateUser(User user);
}
