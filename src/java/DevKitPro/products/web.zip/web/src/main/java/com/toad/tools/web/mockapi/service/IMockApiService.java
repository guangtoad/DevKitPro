package com.toad.tools.web.mockapi.service;

import com.toad.tools.web.mockapi.doamin.MockApi;
import com.toad.tools.web.mockapi.exception.MockApiException;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface IMockApiService {
	List<MockApi> selectMockApiALL();
	List<MockApi> selectMockApiByUrl(String url);
	int updateMockAPI(MockApi mockApi);
	int insertMockApi(MockApi mockApi);
	int deleteMockApi(MockApi mockApi);

	public ResponseEntity<String> requestApi(HttpServletRequest request, HttpServletResponse response);

	public ResponseEntity<String> requestApi(String url, String body, Map<String,String> headers, Map<String,String> params) throws MockApiException;
}
