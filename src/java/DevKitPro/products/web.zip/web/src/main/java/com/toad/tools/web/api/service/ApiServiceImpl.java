package com.toad.tools.web.api.service;

import org.springframework.stereotype.Service;

@Service
public class ApiServiceImpl {
//    @Autowired
//    ApiMapper apiMapper;

//    public List<APIInfo> selectAPIALL(){
//        return apiMapper.selectAPIALL();
//    }
}
