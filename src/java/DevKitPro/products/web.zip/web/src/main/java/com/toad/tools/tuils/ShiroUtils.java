package com.toad.tools.tuils;

import com.toad.tools.common.utils.StringUtils;
import com.toad.tools.common.utils.bean.BeanUtils;
import com.toad.tools.web.shiro.realm.UserRealm;
import com.toad.tools.web.user.domain.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.mgt.RealmSecurityManager;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;

import java.util.List;

public class ShiroUtils{
    public static Subject getSubject()
    {
        return SecurityUtils.getSubject();
    }

    public static Session getSession()
    {
        return SecurityUtils.getSubject().getSession();
    }

    public static void logout()
    {
        getSubject().logout();
    }

    public static User getSysUser()
    {
        User user = null;
        Object obj = getSubject().getPrincipal();
        if (StringUtils.isNotNull(obj))
        {
            user = new User();
            BeanUtils.copyBeanProp(user, obj);
        }
        return user;
    }

    public static void setSysUser(User user)
    {
        Subject subject = getSubject();
        PrincipalCollection principalCollection = subject.getPrincipals();
        String realmName = principalCollection.getRealmNames().iterator().next();
        PrincipalCollection newPrincipalCollection = new SimplePrincipalCollection(user, realmName);
        // 重新加载Principal
        subject.runAs(newPrincipalCollection);
    }

    public static void clearCachedAuthorizationInfo()
    {
        RealmSecurityManager rsm = (RealmSecurityManager) SecurityUtils.getSecurityManager();
//        UserRealm realm = (UserRealm) rsm.getRealms().iterator().next();
//        realm.clearCachedAuthorizationInfo();
    }

    public static Long getUserId()
    {
        return null;
//        return getSysUser().getUserId().longValue();
    }
    /**
     * 安全管理器
     */
    @Bean
    public SecurityManager securityManager(UserRealm userRealm)
    {
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        // 设置realm.
        securityManager.setRealm(userRealm);
//        // 记住我
//        securityManager.setRememberMeManager(rememberMeManager());
//        // 注入缓存管理器;
//        securityManager.setCacheManager(getEhCacheManager());
//        // session管理器
//        securityManager.setSessionManager(sessionManager());
        return securityManager;
    }
    public static String getLoginName()
    {
        return "";
//        return getSysUser().getLoginName();
    }

    public static Integer getProjectId()
    {
        return 12;
//        return getSysUser().getProjectId();
    }

    public static List<Integer> getProjectIdForRoles()
    {
        return null;
//        return getSysUser().getProjectIdForRoles();
    }

    public static String getIp()
    {
        return getSubject().getSession().getHost();
    }

    public static String getSessionId()
    {
        return String.valueOf(getSubject().getSession().getId());
    }
}

