package com.toad.tools.web.development.regexTool.mapper;

public interface RegexEnityMapper {

}
