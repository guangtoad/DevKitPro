package com.toad.tools.web.openapi.doamin;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
public class OpenApiRequestEntiy extends OpenApiEntiy {
}
