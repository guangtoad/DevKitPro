package com.toad.tools.web.api.controller;

import com.toad.tools.lib.BaseController;
import com.toad.tools.web.api.service.IApiService;
import com.toad.tools.web.mockapi.service.IMockApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/api")
public class ApiController extends BaseController {

//	@Autowired
//	IApiService apiService;

	@RequestMapping(value = "/**", produces = "application/json; charset=utf-8")
	public ResponseEntity<String> mockApi(){
		ResponseEntity<String> responseEntity = null;
		responseEntity = ResponseEntity.status(200)
//				.headers(httpHeaders)
				.body("{\"asd\":\"b\"}");
		return responseEntity;
	}
}
