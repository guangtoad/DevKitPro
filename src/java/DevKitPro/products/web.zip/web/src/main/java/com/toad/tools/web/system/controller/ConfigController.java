package com.toad.tools.web.system.controller;

import com.toad.tools.lib.BaseController;
import org.springframework.stereotype.Controller;

@Controller
public class ConfigController extends BaseController {

}
