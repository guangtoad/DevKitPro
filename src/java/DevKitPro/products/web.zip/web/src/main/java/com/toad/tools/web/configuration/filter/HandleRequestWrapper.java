package com.toad.tools.web.configuration.filter;

import org.springframework.boot.web.servlet.filter.ApplicationContextHeaderFilter;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;

@Configuration
public class HandleRequestWrapper implements HandlerInterceptor {

}
