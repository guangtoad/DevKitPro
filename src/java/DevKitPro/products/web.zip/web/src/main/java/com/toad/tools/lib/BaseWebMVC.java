package com.toad.tools.lib;

import com.toad.tools.common.utils.Md5Utils;
import com.toad.tools.tuils.ShiroUtils;
import com.toad.tools.web.config.WebConfig;
import com.toad.tools.web.user.domain.User;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@Data
public class BaseWebMVC {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    protected WebConfig webConfig;

    public User getSysUser()
    {
        return ShiroUtils.getSysUser();
    }

}
