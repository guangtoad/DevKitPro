package com.toad.tools.web.api.mapper;

import com.toad.tools.web.domain.APIInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
public interface ApiMapper {
//    public List<APIInfo> selectAPIALL();
}
