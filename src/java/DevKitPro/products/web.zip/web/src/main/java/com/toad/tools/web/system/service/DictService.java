package com.toad.tools.web.system.service;

import com.toad.tools.web.system.doamin.DictData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("dict")
public class DictService {
	@Autowired
	private IDictDataService dictDataService;

	/**
	 * 根据字典类型查询字典数据信息
	 *
	 * @param dictType 字典类型
	 * @return 参数键值
	 */
	public List<DictData> getType(String dictType)
	{
		List<DictData> result = dictDataService.selectDictDataByType(dictType);
		return result;
	}

	/**
	 * 根据字典类型和字典键值查询字典数据信息
	 *
	 * @param dictType 字典类型
	 * @param dictValue 字典键值
	 * @return 字典标签
	 */
	public String getLabel(String dictType, String dictValue)
	{
		return dictDataService.selectDictLabel(dictType, dictValue);
	}
}
