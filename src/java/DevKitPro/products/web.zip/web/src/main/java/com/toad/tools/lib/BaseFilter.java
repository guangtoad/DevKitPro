package com.toad.tools.lib;

public class BaseFilter  {

}
