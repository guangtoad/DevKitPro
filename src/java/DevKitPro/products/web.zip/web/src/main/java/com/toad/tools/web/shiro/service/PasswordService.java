package com.toad.tools.web.shiro.service;

import com.toad.tools.common.constant.Constants;
import com.toad.tools.common.exception.user.UserPasswordNotMatchException;
import com.toad.tools.common.exception.user.UserPasswordRetryLimitExceedException;
import com.toad.tools.common.utils.AsyncManager;
import com.toad.tools.common.utils.MessageUtils;
import com.toad.tools.common.utils.factory.AsyncFactory;
import com.toad.tools.web.user.domain.User;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class PasswordService {
//	@Autowired
//	private CacheManager cacheManager;

	private Cache<String, AtomicInteger> loginRecordCache;

	@Value(value = "${user.password.maxRetryCount}")
	private String maxRetryCount;

	@PostConstruct
	public void init()
	{
//		loginRecordCache = cacheManager.getCache("loginRecordCache");
	}

	public void validate(User user, String password)
	{
		String loginName = user.getLoginName();

		AtomicInteger retryCount = loginRecordCache.get(loginName);

		if (retryCount == null)
		{
			retryCount = new AtomicInteger(0);
			loginRecordCache.put(loginName, retryCount);
		}
		if (retryCount.incrementAndGet() > Integer.parseInt(maxRetryCount))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(loginName, Constants.LOGIN_FAIL, MessageUtils.message("user.password.retry.limit.exceed", maxRetryCount)));
			throw new UserPasswordRetryLimitExceedException(Integer.parseInt(maxRetryCount));
		}

		if (!matches(user, password))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(loginName, Constants.LOGIN_FAIL, MessageUtils.message("user.password.retry.limit.count", retryCount)));
			loginRecordCache.put(loginName, retryCount);
			throw new UserPasswordNotMatchException();
		}
		else
		{
			clearLoginRecordCache(loginName);
		}
	}
	public boolean matches(User user, String newPassword)
	{
		return user.getPassword().equals(encryptPassword(user.getLoginName(), newPassword, user.getSalt()));
	}
	public String encryptPassword(String username, String password, String salt)
	{
		int iterations = 100000; // 迭代次数（增加计算成本，防止暴力破解）
		Sha256Hash sha256Hash = new Sha256Hash(username + password + salt, salt, iterations);
		return sha256Hash.toHex();
	}
	public void clearLoginRecordCache(String username)
	{
		loginRecordCache.remove(username);
	}
}
