package com.toad.tools.web.user.domain;

import com.toad.tools.annotation.Excel;
import com.toad.tools.lib.BaseEntity;
import lombok.*;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@Accessors(chain = true)
public class User extends BaseEntity
{

    /** 用户ID */
    @Excel(name = "用户序号")
    private Long userId;

    /** 用户名称 */
    @Excel(name = "用户名称")
    private String userName;
	/** 密码 */
	private String password;
    /** 用户邮箱 */
    @Excel(name = "用户邮箱")
    private String email;
	/** 盐加密 */
	private String salt;
    /** 手机号码 */
    @Excel(name = "手机号码")
    private String phonenumber;
    /** 用户头像 */
    @Excel(name = "用户头像")
    private String avatar;
    private int userID;
    private int note;

    /** 登录名称 */
    @Excel(name = "登录名称")
    private String loginName;
    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;
    /** 帐号状态（0正常 1停用） */
    @Excel(name = "帐号状态", readConverterExp = "0=正常,1=停用")
    private String status;
    /** 项目权限列表 */
    private List<Integer> projectIdForRoles;
    /** 最后登陆IP */
    @Excel(name = "最后登陆IP", type = Excel.Type.EXPORT)
    private String loginIp;
    /** 最后登陆时间 */
    @Excel(name = "最后登陆时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss", type = Excel.Type.EXPORT)
    private Date loginDate;
}

