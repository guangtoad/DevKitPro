package com.toad.tools.web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan({"com.toad.tools.web.*.mapper","com.toad.tools.web.*.*.mapper"})
public class ToolsWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToolsWebApplication.class, args);
	}

}
