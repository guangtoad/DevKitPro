package com.toad.tools.web.openapi.doamin;

import lombok.Getter;

@Getter
public class OpenApiResopnseEntiy<T> extends OpenApiEntiy {
    int code;
    String message;
    protected T data;

    public OpenApiResopnseEntiy(int code, String message, T data){

    }

    public static <T> OpenApiResopnseEntiy<T> success(T data) {
        return new OpenApiResopnseEntiy<>(200, "success", data);
    }

    public static <T> OpenApiResopnseEntiy<T> fail(int code, String message, T data) {
        return new OpenApiResopnseEntiy<>(code, message, data);
    }

    public static <T> OpenApiResopnseEntiy<T> fail(int code, T data) {
        return null;
    }

}
