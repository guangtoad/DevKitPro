package com.toad.tools.common.utils.factory;

import com.toad.tools.common.utils.ServletUtils;
import com.toad.tools.tuils.ShiroUtils;

import java.util.TimerTask;

import eu.bitwalker.useragentutils.UserAgent;
public class AsyncFactory {

	public static TimerTask recordLogininfor(final String username, final String status, final String message, final Object... args)
	{
		final UserAgent userAgent = UserAgent.parseUserAgentString(ServletUtils.getRequest().getHeader("User-Agent"));
		final String ip = ShiroUtils.getIp();
		return new TimerTask()
		{
			@Override
			public void run()
			{
//				// 打印信息到日志
//				String s = LogUtils.getBlock(ip) +
//						AddressUtils.getRealAddressByIP(ip) +
//						LogUtils.getBlock(username) +
//						LogUtils.getBlock(status) +
//						LogUtils.getBlock(message);
//				sys_user_logger.info(s, args);
//				// 获取客户端操作系统
//				String os = userAgent.getOperatingSystem().getName();
//				// 获取客户端浏览器
//				String browser = userAgent.getBrowser().getName();
//				// 封装对象
//				Logininfor logininfor = new Logininfor();
//				logininfor.setLoginName(username);
//				logininfor.setIpaddr(ip);
//				logininfor.setLoginLocation(AddressUtils.getRealAddressByIP(ip));
//				logininfor.setBrowser(browser);
//				logininfor.setOs(os);
//				logininfor.setMsg(message);
//				// 日志状态
//				if (Constants.LOGIN_SUCCESS.equals(status) || Constants.LOGOUT.equals(status))
//				{
//					logininfor.setStatus(Constants.SUCCESS);
//				}
//				else if (Constants.LOGIN_FAIL.equals(status))
//				{
//					logininfor.setStatus(Constants.FAIL);
//				}
//				// 插入数据
//				SpringUtils.getBean(LogininforServiceImpl.class).insertLogininfor(logininfor);
			}
		};
	}
}
