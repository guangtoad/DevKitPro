package com.toad.tools.web.config;

import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import com.toad.tools.common.utils.StringUtils;
import com.toad.tools.web.shiro.realm.CustomerRealm;
import org.apache.commons.io.IOUtils;
import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.apache.shiro.config.ConfigurationException;
import org.apache.shiro.lang.io.ResourceUtils;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {

	public static final String PREMISSION_STRING = "perms[\"{0}\"]";

	// 登录地址
//	@Value("${shiro.user.loginUrl}")
//	private String loginUrl;

	/**
	 * 缓存管理器 使用Ehcache实现
	 */
//	@Bean
//	public EhCacheManager getEhCacheManager()
//	{
//		net.sf.ehcache.CacheManager cacheManager = net.sf.ehcache.CacheManager.getCacheManager("luckyframe");
//		EhCacheManager em = new EhCacheManager();
//		if (StringUtils.isNull(cacheManager))
//		{
//			em.setCacheManager(new net.sf.ehcache.CacheManager(getCacheManagerConfigFileInputStream()));
//			return em;
//		}
//		else
//		{
//			em.setCacheManager(cacheManager);
//			return em;
//		}
//	}
	//ShiroFilter过滤所有请求
	@Bean
	public ShiroFilterFactoryBean getShiroFilterFactoryBean(DefaultWebSecurityManager securityManager) {
		ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
		//给ShiroFilter配置安全管理器
		shiroFilterFactoryBean.setSecurityManager(securityManager);
		//配置系统受限资源
		//配置系统公共资源
		Map<String, String> map = new HashMap<String, String>();
		map.put("/index.jsp","authc");//表示这个资源需要认证和授权
		// 设置认证界面路径
		shiroFilterFactoryBean.setLoginUrl("/login.jsp");
		shiroFilterFactoryBean.setFilterChainDefinitionMap(map);

		return shiroFilterFactoryBean;
	}
	//创建安全管理器
	@Bean()
	public DefaultWebSecurityManager getDefaultWebSecurityManager(Realm realm) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		securityManager.setRealm(realm);
		return securityManager;
	}

	/**
	 * 返回配置文件流 避免ehcache配置文件一直被占用，无法完全销毁项目重新部署
	 */
	protected InputStream getCacheManagerConfigFileInputStream()
	{
		String configFile = "classpath:ehcache/ehcache-shiro.xml";
		InputStream inputStream = null;
		try
		{
			inputStream = ResourceUtils.getInputStreamForPath(configFile);
			byte[] b = IOUtils.toByteArray(inputStream);
			return new ByteArrayInputStream(b);
		}
		catch (IOException e)
		{
			throw new ConfigurationException(
					"Unable to obtain input stream for cacheManagerConfigFile [" + configFile + "]", e);
		}
		finally
		{
			IOUtils.closeQuietly(inputStream);
		}
	}
//	@Bean
//	public SecurityManager securityManager(Realm realm)
//	{
//		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
//		// 设置realm.
//		securityManager.setRealm(realm);
////		// 记住我
////		securityManager.setRememberMeManager(rememberMeManager());
//		// 注入缓存管理器;
//		securityManager.setCacheManager(getEhCacheManager());
////		// session管理器
////		securityManager.setSessionManager(sessionManager());
//		return securityManager;
//	}
	//创建自定义Realm
	@Bean
	public CustomerRealm customerRealm() {
		CustomerRealm realm = new CustomerRealm();
		return realm;
	}
	/**
	 * thymeleaf模板引擎和shiro框架的整合
	 */
	@Bean
	public ShiroDialect shiroDialect()
	{
		return new ShiroDialect();
	}
//	/**
//	 * 开启Shiro注解通知器
//	 */
//	@Bean
//	public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(
//			@Qualifier("securityManager") SecurityManager securityManager)
//	{
//		AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
//		authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
//		return authorizationAttributeSourceAdvisor;
//	}
}
