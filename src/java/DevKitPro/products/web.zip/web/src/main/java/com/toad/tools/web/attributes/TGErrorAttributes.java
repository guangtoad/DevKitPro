package com.toad.tools.web.attributes;

import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

@Component
public class TGErrorAttributes extends DefaultErrorAttributes {
    @Override
    public Map<String, Object> getErrorAttributes(WebRequest webRequest, ErrorAttributeOptions options) {
        Map<String, Object> errorAttributes = super.getErrorAttributes(webRequest, options);
        Object error = errorAttributes.get("error");
        Object status =  errorAttributes.get("status");
        Map<String,Object> result = new HashMap<>();
        String message = "";
        if (null != error) {
            message = error.toString();
        }
        else {
            message = "未知错误";
        }
        result.put("message",message);
        result.put("code",status);
        return result;
    }
}
