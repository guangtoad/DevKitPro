package com.toad.tools.web.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("config")
public class ConfigService {
	@Autowired
	private IConfigService configService;

	/**
	 * 根据键名查询参数配置信息
	 *
	 * @param configKey 参数名称
	 * @return 参数键值
	 */
	public String getKey(String configKey)
	{
		return configService.selectConfigByKey(configKey);
	}
}
