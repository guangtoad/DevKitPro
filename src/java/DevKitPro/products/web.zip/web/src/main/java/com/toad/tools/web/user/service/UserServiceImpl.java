package com.toad.tools.web.user.service;

import com.toad.tools.web.user.domain.User;
import com.toad.tools.web.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }

    @Override
    public List<User> findAllTwo() {
        return userMapper.findAllTwo();
    }

    @Override
    public User selectUserByLoginName(String userName) {
        return userMapper.selectUserByLoginName(userName);
    }

    @Override
    public User selectUserByPhoneNumber(String phoneNumber) {
        return null;
    }

    @Override
    public User selectUserByEmail(String email) {
        return null;
    }

    @Override
    public int updateUserInfo(User user) {
        return 0;
    }



}
