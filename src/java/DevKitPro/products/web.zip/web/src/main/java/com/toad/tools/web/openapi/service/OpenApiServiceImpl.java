package com.toad.tools.web.openapi.service;

import com.toad.tools.lib.BaseServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class OpenApiServiceImpl extends BaseServiceImpl {
    public String auth(){
        return "";
    }
}
