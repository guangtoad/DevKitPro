package com.toad.tools.web.openapi.service;

public interface IOpenApiService {
    public String auth();
}
