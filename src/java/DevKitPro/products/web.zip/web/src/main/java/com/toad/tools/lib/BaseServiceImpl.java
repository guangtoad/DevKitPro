package com.toad.tools.lib;

public class BaseServiceImpl extends BaseService{
}
