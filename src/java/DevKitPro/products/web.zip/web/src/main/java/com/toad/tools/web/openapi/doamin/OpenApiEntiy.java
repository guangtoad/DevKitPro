package com.toad.tools.web.openapi.doamin;

import com.toad.tools.lib.BaseEntity;

public class OpenApiEntiy<T> {

}
