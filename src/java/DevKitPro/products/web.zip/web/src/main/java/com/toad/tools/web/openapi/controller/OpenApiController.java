package com.toad.tools.web.openapi.controller;

import com.toad.tools.lib.BaseController;
import com.toad.tools.web.openapi.doamin.OpenApiResopnseEntiy;
import com.toad.tools.web.openapi.service.IOpenApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/openapi")
public class OpenApiController extends BaseController {
//    @Autowired
    IOpenApiService openApiService;

    @PostMapping("/token")
    public OpenApiResopnseEntiy<String> token(){
        this.logger.info("用户获取Token");

        return OpenApiResopnseEntiy.success("aaa");
    }
}
