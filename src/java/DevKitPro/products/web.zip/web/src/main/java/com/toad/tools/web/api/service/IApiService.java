package com.toad.tools.web.api.service;

import org.springframework.stereotype.Service;

@Service
public interface IApiService {
}
