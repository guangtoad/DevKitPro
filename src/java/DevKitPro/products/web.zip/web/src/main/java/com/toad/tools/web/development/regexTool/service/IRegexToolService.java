package com.toad.tools.web.development.regexTool.service;

public interface IRegexToolService {
}
