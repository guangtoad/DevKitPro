package com.toad.tools.web.mockapi.controller;

import com.toad.tools.web.mockapi.exception.MockApiException;
import com.toad.tools.web.mockapi.service.IMockApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Controller
public class MockApiController {
	@Autowired
	IMockApiService mockApiService;

	@GetMapping("/mockapi/mockapi")
	public String mockApi(){
		return "/mockapi/mockapi";
	}


	@RequestMapping("/api/**")
	public ResponseEntity<String> reqeustApi(HttpServletRequest request, HttpServletResponse response){
		ResponseEntity<String> responseEntity = null;
		try	{
			String requestURI = request.getRequestURI();
			Map<String,String> resHeader = null;
			responseEntity = this.mockApiService.requestApi(requestURI, "", null, null);
		}
		catch (MockApiException e){
			responseEntity = ResponseEntity.status(e.httpStatus)
					.body(e.getMessage());
		}
		catch (Exception e){
			responseEntity =
					responseEntity = ResponseEntity.status(500)
							.body("Exception:\n"+ e);
		}
		return responseEntity;
	}
}
