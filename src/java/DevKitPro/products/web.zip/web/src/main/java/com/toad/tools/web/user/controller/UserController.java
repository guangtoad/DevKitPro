package com.toad.tools.web.user.controller;

import com.toad.tools.lib.BaseController;

public class UserController extends BaseController {

}
