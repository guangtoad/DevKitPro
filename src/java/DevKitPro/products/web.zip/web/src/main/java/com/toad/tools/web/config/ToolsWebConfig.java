package com.toad.tools.web.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "twebcon")
@Getter
@Setter
public class ToolsWebConfig {
	private String name;
	private String version;
	private boolean demoEnabled;
	private boolean addressEnabled;
}
