package com.toad.tools.web.shiro.realm;

import com.toad.tools.web.shiro.service.LoginService;
import com.toad.tools.web.user.domain.User;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 自定义Realm
 */
public class CustomerRealm extends AuthorizingRealm {

	@Autowired
	private LoginService loginService;

	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
		return null;
	}

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
		UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) authenticationToken;
		String userName = usernamePasswordToken.getUsername();
		String password = "";
		if (null != usernamePasswordToken.getPassword()){
			password = new String(usernamePasswordToken.getPassword());
		}
		User user = null;
		try {
			user =  loginService.login(userName, password);
		}
		catch (Exception e){
			throw e;
		}
		return new SimpleAuthenticationInfo(user, password, getName());
	}
}