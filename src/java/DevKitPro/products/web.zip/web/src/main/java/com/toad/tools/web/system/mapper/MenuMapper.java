package com.toad.tools.web.system.mapper;

import com.toad.tools.web.system.doamin.Menu;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 菜单表 数据层
 *
 * @author ruoyi
 */
//@Mapper
@Component
public interface MenuMapper
{
    /**
     * 查询系统所有菜单（含按钮）
     *
     * @return 菜单列表
     */
    List<Menu> selectMenuAll();
}
