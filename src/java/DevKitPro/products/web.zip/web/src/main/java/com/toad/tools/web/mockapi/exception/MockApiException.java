package com.toad.tools.web.mockapi.exception;

import org.springframework.http.HttpHeaders;

/**
 * 模拟接口异常
 */
public class MockApiException extends Exception{

    public int httpStatus = 500;
    public HttpHeaders headers = null;

    public MockApiException(int httpStatus, String message){
        super(message);
        this.httpStatus = httpStatus;
    }

    static public MockApiException ErrorException(String message){
        return new MockApiException(500, message);
    }
    static public MockApiException BadReqeustException(String message){
        return new MockApiException(400, message);
    }
    static public MockApiException NotFoundException(String message){
        return new MockApiException(404, message);
    }
}
