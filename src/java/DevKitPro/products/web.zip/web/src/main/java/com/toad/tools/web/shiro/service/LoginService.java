package com.toad.tools.web.shiro.service;

import com.toad.tools.common.constant.Constants;
import com.toad.tools.common.constant.UserConstants;
import com.toad.tools.common.exception.user.UserBlockedException;
import com.toad.tools.common.exception.user.UserDeleteException;
import com.toad.tools.common.exception.user.UserNotExistsException;
import com.toad.tools.common.exception.user.UserPasswordNotMatchException;
import com.toad.tools.common.utils.AsyncManager;
import com.toad.tools.common.utils.MessageUtils;
import com.toad.tools.common.utils.factory.AsyncFactory;
import com.toad.tools.tuils.ShiroUtils;
import com.toad.tools.lib.BaseService;
import com.toad.tools.web.user.domain.User;
import com.toad.tools.web.user.domain.UserStatus;
import com.toad.tools.web.user.service.IUserService;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheManager;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class LoginService extends BaseService {

	private Cache<String, AtomicInteger> loginRecordCache;

//	@Autowired
	private CacheManager cacheManager;

	@Autowired
	private IUserService userService;

	@Value(value = "${user.password.maxRetryCount}")
	private String maxRetryCount;

//	@Autowired
	private PasswordService passwordService;

	private boolean maybeEmail(String username)
	{
		return username.matches(UserConstants.EMAIL_PATTERN);
	}
	private boolean maybeMobilePhoneNumber(String username)
	{
		return username.matches(UserConstants.MOBILE_PHONE_NUMBER_PATTERN);
	}
	/**
	 * 记录登录信息
	 */
	public void recordLoginInfo(User user)
	{
		user.setLoginIp(ShiroUtils.getIp());
		user.setLoginDate(new Date());
		userService.updateUserInfo(user);
	}

	/**
	 * 登录
	 */
	public User login(String username, String password)
	{
		// 用户名或密码为空 错误
		if (!StringUtils.hasLength(username) || !StringUtils.hasLength(password))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("not.null")));
			throw new UserNotExistsException();
		}
		// 密码如果不在指定范围内 错误
		if (password.length() < UserConstants.PASSWORD_MIN_LENGTH
				|| password.length() > UserConstants.PASSWORD_MAX_LENGTH)
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("user.password.not.match")));
			throw new UserPasswordNotMatchException();
		}

		// 用户名不在指定范围内 错误
		if (username.length() < UserConstants.USERNAME_MIN_LENGTH
				|| username.length() > UserConstants.USERNAME_MAX_LENGTH)
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("user.password.not.match")));
			throw new UserPasswordNotMatchException();
		}

		// 查询用户信息
		User user = userService.selectUserByLoginName(username);

		if (user == null && maybeMobilePhoneNumber(username))
		{
			user = userService.selectUserByPhoneNumber(username);
		}

		if (user == null && maybeEmail(username))
		{
			user = userService.selectUserByEmail(username);
		}

		if (user == null)
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("user.not.exists")));
			throw new UserNotExistsException();
		}

		if (UserStatus.DELETED.getCode().equals(user.getDelFlag()))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("user.password.delete")));
			throw new UserDeleteException();
		}

		if (UserStatus.DISABLE.getCode().equals(user.getStatus()))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_FAIL, MessageUtils.message("user.blocked", user.getRemark())));
			throw new UserBlockedException();
		}

		this.validate(user, password);

//		/*加入项目权限ID列表*/
//		user.setProjectIdForRoles(roleProjectService.selectProjectPermsByUserId(user.getUserId()));

		AsyncManager.me().execute(AsyncFactory.recordLogininfor(username, Constants.LOGIN_SUCCESS, MessageUtils.message("user.login.success")));
//		recordLoginInfo(user);
		return user;
	}
	public void validate(User user, String password){

		String loginName = user.getLoginName();
		AtomicInteger retryCount = loginRecordCache.get(loginName);
		if (retryCount == null)
		{
			retryCount = new AtomicInteger(0);
			loginRecordCache.put(loginName, retryCount);
		}
		else {

		}
		if (retryCount.incrementAndGet() > Integer.parseInt(maxRetryCount))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(loginName, Constants.LOGIN_FAIL, MessageUtils.message("user.password.retry.limit.exceed", maxRetryCount)));
//			throw new UserPasswordRetryLimitExceedException(Integer.parseInt(maxRetryCount));
		}
		else {

		}
		if (!matches(user, password))
		{
			AsyncManager.me().execute(AsyncFactory.recordLogininfor(loginName, Constants.LOGIN_FAIL, MessageUtils.message("user.password.retry.limit.count", retryCount)));
			loginRecordCache.put(loginName, retryCount);
			throw new UserPasswordNotMatchException();
		}
		else
		{
			clearLoginRecordCache(loginName);
		}
	}
	public boolean checkPassword(String password)
	{
		User user = getSysUser();
		return this.matches(user, password);
	}

	public boolean matches(User user, String newPassword)
	{
		return user.getPassword().equals(encryptPassword(user.getLoginName(), newPassword, user.getSalt()));
	}
	public String encryptPassword(String username, String password, String salt)
	{
		int iterations = 100000; // 迭代次数（增加计算成本，防止暴力破解）
		Sha256Hash sha256Hash = new Sha256Hash(username + password + salt, salt, iterations);
		return sha256Hash.toHex();
	}
	public void clearLoginRecordCache(String username)
	{
		loginRecordCache.remove(username);
	}
}
