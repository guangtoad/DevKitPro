package com.toad.tools.web.mockapi.mapper;

import com.toad.tools.web.mockapi.doamin.MockApi;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface MockApiMapper {
	List<MockApi> selectMockApiALL();
	List<MockApi> selectMockApiByUrl(String url);
	int updateMockAPI(MockApi mockApi);
	int insertMockApi(MockApi mockApi);
	int deleteMockApi(MockApi mockApi);
}

