package com.toad.tools.lib;


import com.toad.tools.lib.BaseWebMVC;

public class BaseService extends BaseWebMVC {
}
