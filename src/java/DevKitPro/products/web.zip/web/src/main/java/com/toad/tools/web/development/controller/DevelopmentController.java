package com.toad.tools.web.development.controller;

import com.toad.tools.lib.BaseController;
import org.apache.bsf.BSFException;
import org.apache.bsf.BSFManager;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
//import org.apache.bsf

@Controller
@RequestMapping("/development")
public class DevelopmentController extends BaseController {

	public DevelopmentController(){
//		this.setBasePath("/development");
	}

	@GetMapping("/development/regexTool/regextool")
	String regexTool(){
		return "/development/regexTool/regextool";
	}

	@GetMapping("/aes")
	String aes(){
		return this.templateByBasePath("/aes");
	}

	@GetMapping("/bsh")
	String bsh(){
		return this.templateByBasePath("/bsh");
	}

	@PostMapping("/bsh")
	ResponseEntity<String> reqeustBase(@RequestBody(required = false) String body){

		ResponseEntity<String> responseEntity = null;
		BSFManager mgr = new BSFManager();
		try {
			// Set variables
			mgr.declareBean("var1", 5, Integer.class);
			mgr.declareBean("date",  new Date(), Date.class);
			String script = "import java.util.Date;"
					+" String var1 = var1 + \"_\" + date.toString();"
					+" return var1";
			Object result = mgr.eval("beanshell", "no", 0, 0, script);
			responseEntity = ResponseEntity.status(200).body("source result:" + result);
//			System.out.println("source result:" + result);
		}
		catch (BSFException e) {
			responseEntity = ResponseEntity.status(500).body(e.getMessage());
		}
		catch (Exception e){
			responseEntity = ResponseEntity.status(500).body(e.getMessage());
		}

		return responseEntity;
	}

	@RequestMapping(value="/{page}",method= RequestMethod.GET)
	String other(@PathVariable(name = "page",required = false) String page){
		if (null != page && page.length() > 0)
			return this.templateByBasePath("/" + page	);
		return this.templateByBasePath("");

	}

}
